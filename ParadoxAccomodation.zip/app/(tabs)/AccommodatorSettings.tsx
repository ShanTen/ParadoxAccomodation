import { StyleSheet } from 'react-native';
import { Text, View } from '@/components/Themed';
import { useState } from 'react';

import ProfileBar from '../CommonComponents/ProfileBar';

function HostelDetails({name, totalStudents, studentsCheckedIn} : {name: string, totalStudents: number, studentsCheckedIn: number}){
  return (
    <View style={Styles.hostelStatsContainer}>
      <Text style={Styles.hostelStatsTitle}>Hostel Details</Text>
      <Text style={Styles.hostelStatsText}>Name: {name}</Text>
      <Text style={Styles.hostelStatsText}>Total Students: {totalStudents}</Text>
      <Text style={Styles.hostelStatsText}>Students Checked In: {studentsCheckedIn}</Text>
      <Text style={Styles.hostelStatsText}>Students Not Checked In: {totalStudents-studentsCheckedIn}</Text>
    </View>
  )
}

export default function AccommodatorScreen() {
  const [volunteerDetails, setVolunteerDetails] = useState({
    profileName: "Ashok Kumar",
    profilePicture: "https://ui-avatars.com/api/?name=Ashok+Kumar&?background=000000&color=0D8ABC&?format=svg?size=256",
    uniqueID: "20f1000001",
  });

  const [hostelDetails, setHostelDetails] = useState({
    name: "Saraswati Hostel",
    totalStudents: 0,
    studentsCheckedIn: 0,
  });
  
  return (
    <View style={Styles.container}>
      <Text style={Styles.title}>Volunteer Details</Text>
      <View style={Styles.separator} lightColor="#eee" darkColor="rgba(255,255,255,0.1)" />

      <ProfileBar 
        profilePicture={volunteerDetails.profilePicture}
        profileName={volunteerDetails.profileName}
        uniqueID={volunteerDetails.uniqueID}
      />

      <HostelDetails 
        name={hostelDetails.name}
        totalStudents={hostelDetails.totalStudents}
        studentsCheckedIn={hostelDetails.studentsCheckedIn}
      />

    </View>
  );
}

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
  },
  title: {
    marginTop: 60,
    fontSize: 20,
    fontWeight: 'bold',
  },
  separator: {
    marginVertical: 1,
    marginBottom: 20,
    height: 1,
    width: '80%',
  },
  hostelStatsContainer: {
    flex: 0,
    width: '90%',
    marginTop: 20,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',

    // backgroundColor: '#1E1E1E',
  },
  hostelStatsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#E3E3E3',
  },
  hostelStatsText: {
    fontSize: 15,
    padding: 4,
    color: '#E3E3E3',
  },
});
