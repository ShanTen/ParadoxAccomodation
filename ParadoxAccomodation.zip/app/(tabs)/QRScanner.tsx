/*
  Expo Go's QR Scanner Screen Implementation for Accommodator App

    ToDo:
    - Overhaul their state object and create my own state implementations -- done
    - Can also remove all platform unifying code (ios being a bitch code basically), -- done 
        because target users are only android  
    - Add a stack navigator for this page only => StackNavSupplyHandle
        Parts:
          - QR Scanner (Home)
          - HandleSupplies (Home -> OTP Supplies)
          - OTPSupplies (OTP Supplies -> Home)
*/

///////////////////////////////////////////////////////////////////////////////
///////////////////////// Imported Modules  ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
import * as BarCodeScanner from 'expo-barcode-scanner';
import { BlurView } from 'expo-blur';
import { FlashMode } from 'expo-camera';
import { throttle } from 'lodash';
import React from 'react';
import { Alert, Linking, Platform, StatusBar, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Camera } from '../CommonComponents/Camera';
import QRFooterButton from '../CommonComponents/QRFooterButton';
import QRIndicator from '../CommonComponents/QRIndicator';

/* Navigation Handler For Post QR Scan */
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HandleSupplies from '../Screens/HandleSupplies';
import OTPSupply from '../Screens/OTPSupply';

///////////////////////////////////////////////////////////////////////////////
///////////////////// Navigation Handler For Post QR Scan /////////////////////
///////////////////////////////////////////////////////////////////////////////

const StackNavSupplyHandle = createNativeStackNavigator();

///////////////////////////////////////////////////////////////////////////////
///////////////////////// Page Specific Components  ///////////////////////////
///////////////////////////////////////////////////////////////////////////////

function CurrentPayloadDisplay({payload}: {payload: string | null}){
  return (<View style={Styles.CurrentPayloadDisplay}>
    <Text style={Styles.CurrentPayloadDisplayText}>Current Payload: [{payload || "No Payload Set"}]</Text>
  </View>)
}

function Hint({ children }: { children: string }) {
  return (
    <BlurView style={Styles.hint} intensity={100} tint="dark">
      <Text style={Styles.headerText}>{children}</Text>
    </BlurView>
  );
}

///////////////////////////////////////////////////////////////////////////////
//////////////////////// Main Export Method ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// const initialState: State = { isVisible: Platform.OS === 'ios', url: null };
// defaults to {isVisible: false, url: null} on Android

function BarCodeScreen({ navigation }: { navigation: any }) {
  const [isVisible , setIsVisible] = React.useState(false)
  const [url , setUrl] = React.useState<string | null>(null)
  const [mountKey, setMountKey] = React.useState(0); //camera hack to force remount
  
  const [isLit, setLit] = React.useState(false);

  React.useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    // InstanceOf : [state]
    if (!isVisible) {
      timeout = setTimeout(() => {
        setIsVisible(true);
      }, 800);
    }
    return () => {
      clearTimeout(timeout);
    };
  }, []);

  React.useEffect(() => {
    if (!isVisible && url) {
      console.log("QR Code Scanned")
      //NAV :: Move to Next Screen
      navigation.navigate('HandleSupplies', {QRid: url});
    }
  }, [isVisible, url]);

  // InstanceOf : [state]
  const _handleBarCodeScanned = throttle(({ data: _url }) => {
    console.log("Scanned URL: ", _url)
    setUrl(_url);
    setIsVisible(false);
  }, 1000);

  const openUrl = (_url: string) => {
    // InstanceOf : [props.navigation]
    // props.navigation.pop();

    setTimeout(
      () => {
        // note(brentvatne): Manually reset the status bar before opening the
        // experience so that we restore the correct status bar color when
        // returning to home
        StatusBar.setBarStyle('default');
        Linking.openURL(_url);
      },
      Platform.select({default: 500,})
    );
  };

  // InstanceOf : [props.navigation]
  const onCancel = React.useCallback(() => {
    console.log("Action Cancelled")
    //clear all states
    setUrl(null);
    setIsVisible(true);
    //unmount camera
    setMountKey((key) => key + 1);


  }, []);

  const onFlashToggle = React.useCallback(() => {
    setLit((isLit) => !isLit);
  }, []);

  const { top, bottom } = useSafeAreaInsets();

  return (
    <View style={Styles.container}>
      {/* // InstanceOf : [state] */}
      {isVisible ? (
        <Camera
          key={mountKey}
          barCodeScannerSettings={{
            barCodeTypes: [BarCodeScanner.Constants.BarCodeType.qr],
          }}
          onBarCodeScanned={_handleBarCodeScanned}
          style={StyleSheet.absoluteFill}
          flashMode={isLit ? FlashMode.torch : FlashMode.off}
        />
      ) : null}

      <View style={[Styles.header, { top: 40 + top }]}>
        <Hint>Scan the generated QR</Hint>
      </View>
      <QRIndicator />
      <CurrentPayloadDisplay payload={url}/>
      <View style={[Styles.footer, { bottom: 30 + bottom }]}>
        <QRFooterButton onPress={onFlashToggle} isActive={isLit} iconName="flashlight" />
        <QRFooterButton onPress={onCancel} iconName="close" iconSize={48} />
      </View>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
    </View>
  );
}

export default function SupplyHandlerScreen() {
  return <StackNavSupplyHandle.Navigator>
        <StackNavSupplyHandle.Screen name="Home" component={BarCodeScreen} options={{headerShown: false}}/>
        <StackNavSupplyHandle.Screen name="HandleSupplies" component={HandleSupplies} options={{headerShown: false}}/>
        <StackNavSupplyHandle.Screen name="OTPSupply" component={OTPSupply} options={{headerShown: false}}/>
      </StackNavSupplyHandle.Navigator>
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////// Stylesheet  /////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hint: {
    paddingHorizontal: 16,
    paddingVertical: 20,
    borderRadius: 16,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  headerText: {
    color: '#fff',
    backgroundColor: 'transparent',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '500',
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: '10%',
  },
  CurrentPayloadDisplay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 100,
    padding: 20,
    borderRadius: 16,
    color: '#fff',
    backgroundColor: 'transparent',
  },
  CurrentPayloadDisplayText:{
    color: 'white',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '500',
  }
});